# MG Home Page Project

This static page was made using HTML, CSS, and JS by Kevin Ma.